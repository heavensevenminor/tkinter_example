from tkinter import *

master = Tk()

master.mainloop()