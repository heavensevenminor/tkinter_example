import tkinter as tk

master = tk.Tk()

master.mainloop()